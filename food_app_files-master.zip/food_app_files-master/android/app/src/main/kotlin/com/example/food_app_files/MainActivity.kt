package com.example.food_app_files

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
