import 'package:flutter/cupertino.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:user_app/global/global.dart';

class CartItemCounter extends ChangeNotifier{
  int CartListItemCounter = sharedPreferences!.getStringList("userCart")!.length-1;
  int get count => CartListItemCounter;

  Future<void> displayCartListItemsNumber() async{
    CartListItemCounter = sharedPreferences!.getStringList("userCart")!.length -1;

    await Future.delayed(const Duration(milliseconds: 100), (){
      notifyListeners();
    });
  }
}